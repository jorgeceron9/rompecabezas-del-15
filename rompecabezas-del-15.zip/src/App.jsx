
import React, { useState, useEffect } from "react";

const SIZE = 4;

function crearTableroInicial() {
  const numeros = Array.from({ length: SIZE * SIZE }, (_, i) => i);
  for (let i = numeros.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [numeros[i], numeros[j]] = [numeros[j], numeros[i]];
  }
  return Array.from({ length: SIZE }, (_, i) =>
    numeros.slice(i * SIZE, i * SIZE + SIZE)
  );
}

function encontrarVacio(tablero) {
  for (let i = 0; i < SIZE; i++) {
    for (let j = 0; j < SIZE; j++) {
      if (tablero[i][j] === 0) return { fila: i, col: j };
    }
  }
}

function mover(tablero, fila, col) {
  const nuevoTablero = tablero.map(f => f.slice());
  const vacio = encontrarVacio(nuevoTablero);
  const dx = Math.abs(vacio.fila - fila);
  const dy = Math.abs(vacio.col - col);
  if (dx + dy === 1) {
    [nuevoTablero[vacio.fila][vacio.col], nuevoTablero[fila][col]] = 
    [nuevoTablero[fila][col], nuevoTablero[vacio.fila][vacio.col]];
  }
  return nuevoTablero;
}

export default function Rompecabezas15() {
  const [tablero, setTablero] = useState(crearTableroInicial());

  function reiniciar() {
    setTablero(crearTableroInicial());
  }

  return (
    <div className="p-4">
      <h1 className="text-2xl font-bold mb-4">Rompecabezas del 15</h1>
      <div className="grid grid-cols-4 gap-2 w-64 mx-auto">
        {tablero.flat().map((valor, idx) => {
          const fila = Math.floor(idx / SIZE);
          const col = idx % SIZE;
          return (
            <button
              key={idx}
              onClick={() => setTablero(mover(tablero, fila, col))}
              className={`w-16 h-16 flex items-center justify-center rounded text-lg font-semibold 
                ${valor === 0 ? "bg-gray-200" : "bg-blue-400 text-white"}`}
            >
              {valor !== 0 ? valor : ""}
            </button>
          );
        })}
      </div>
      <button onClick={reiniciar} className="mt-4 px-4 py-2 bg-green-500 text-white rounded">
        Reiniciar
      </button>
    </div>
  );
}
