
import React from "react";
import ReactDOM from "react-dom/client";
import Rompecabezas15 from "./App";
import "./index.css";

const root = ReactDOM.createRoot(document.getElementById("root"));
root.render(
  <React.StrictMode>
    <Rompecabezas15 />
  </React.StrictMode>
);
